"""
============================================================
ANALISIS DE SEÑALES DE PULSO (4 CICLOS UTILES DISTINTOS)
Laboratorio: Procesamiento de Señales para Comunicaciones - UMNG
Compatible con Thonny (Python estandar + numpy + matplotlib)

Procesa Pulso 1 (50%), Pulso 2 (20%), Pulso 3 (30%) y Pulso 4 (80%):
  - Lee el CSV del dominio del tiempo y el CSV del espectro FFT
    exportados por el osciloscopio Tektronix TDS 2012B
  - Calcula la frecuencia de muestreo real
  - Calcula la FFT por software y la compara con la del osciloscopio
  - Extrae los primeros armonicos experimentales
  - Reconstruye la señal teorica (serie de Fourier de un tren de
    pulsos con el duty correspondiente) y la experimental
  - Calcula el error RMS de cada reconstruccion
  - Guarda graficas (.png) y tablas de armonicos (.csv) en resultados/
============================================================
"""

import csv
import os
import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# PARAMETROS DEL GRUPO (Tabla 2 de la guia) -> Grupo 7
# ============================================================
f0 = 3500      # Frecuencia fundamental (Hz)
Vp = 1.5       # Voltaje pico (V)
Narmonicos = 15

# ============================================================
# SEÑALES DE PULSO A PROCESAR (Tabla 1 de la guia)
# Edita los nombres de archivo si los tuyos son distintos
# ============================================================
señales = [
    {"nombre": "Pulso 1", "duty": 0.50,
     "archivo_tiempo": "Pulso 1tiemdta.csv", "archivo_fft": "Pulso 1DTA.csv"},
    {"nombre": "Pulso 2", "duty": 0.20,
     "archivo_tiempo": "Pulso 2tiemdata.csv", "archivo_fft": "Pulso 2DATA.csv"},
    {"nombre": "Pulso 3", "duty": 0.30,
     "archivo_tiempo": "Pulso 3TIEMDAT.csv", "archivo_fft": "Pulso 3DATA.csv"},
    {"nombre": "Pulso 4", "duty": 0.80,
     "archivo_tiempo": "Pulso 4TIEMDATA.csv", "archivo_fft": "Pulso 4DATA.csv"},
]

CARPETA_DATOS = "."             # carpeta donde estan los CSV
CARPETA_SALIDA = "resultados"   # carpeta donde se guardan graficas/tablas
os.makedirs(CARPETA_SALIDA, exist_ok=True)


# ============================================================
# FUNCION: leer archivo CSV exportado por el osciloscopio Tektronix
# ============================================================
def leer_csv_tektronix(ruta):
    """
    Lee un CSV exportado por el osciloscopio TDS 2012B.
    Devuelve: metadatos (dict), eje_x (np.array), eje_y (np.array)
    Columnas 1-2: metadatos (etiqueta, valor). Columnas 4-5: datos (x, y).
    """
    metadatos = {}
    eje_x, eje_y = [], []

    with open(ruta, encoding="latin-1") as f:
        lector = csv.reader(f)
        for fila in lector:
            if len(fila) < 2:
                continue
            if fila[0].strip() != "":
                metadatos[fila[0].strip()] = fila[1].strip()
            if len(fila) >= 5 and fila[3].strip() != "" and fila[4].strip() != "":
                try:
                    x = float(fila[3])
                    y = float(fila[4])
                    eje_x.append(x)
                    eje_y.append(y)
                except ValueError:
                    pass

    return metadatos, np.array(eje_x), np.array(eje_y)


# ============================================================
# FUNCION: FFT calculada por software (magnitud de un solo lado)
# ============================================================
def fft_software(t, x, f0_referencia=None):
    """
    Calcula la FFT de un solo lado.

    NOTA IMPORTANTE (Punto 4 de la guia - caracterizacion instrumental):
    El campo "Sample Interval" del CSV del osciloscopio viene con la
    unidad "s" pero el valor (ej. 4.00000) es en realidad un valor
    en bruto sin el exponente real (el osciloscopio SI muestrea en
    el orden de microsegundos para señales de kHz, no en segundos).
    Por eso, en vez de confiar ciegamente en el encabezado, aqui se
    CALIBRA la frecuencia de muestreo real usando la frecuencia
    fundamental conocida de la señal (f0_referencia, del grupo de
    trabajo): se ubica el bin de mayor energia de la FFT (el armonico
    fundamental) y se le asigna la frecuencia f0 conocida; de ahi se
    despeja la Fs real. Esto es exactamente la verificacion que pide
    el punto 4 de la guia.
    """
    dt_bruto = np.mean(np.diff(t))
    Fs_bruto = 1 / dt_bruto  # Fs "de encabezado" (probablemente incorrecta)

    N = len(x)
    Y = np.fft.fft(x)
    P2 = np.abs(Y) / N
    n2 = N // 2
    P1 = P2[:n2 + 1].copy()
    if len(P1) > 2:
        P1[1:-1] *= 2

    fase = np.angle(Y[:n2 + 1])

    if f0_referencia is not None:
        # Se busca el bin de mayor magnitud (excluyendo DC, k=0)
        # y se calibra la Fs para que ese bin corresponda a f0_referencia
        k_pico = np.argmax(P1[1:]) + 1
        Fs = f0_referencia * N / k_pico
        print(f"    [Calibracion] Fs de encabezado = {Fs_bruto:.4f} Hz (NO fiable)")
        print(f"    [Calibracion] Bin fundamental detectado en k={k_pico} -> "
              f"Fs real calibrada = {Fs:.2f} Hz")
    else:
        Fs = Fs_bruto

    f = Fs * np.arange(0, n2 + 1) / N

    return Fs, f, P1, fase


# ============================================================
# FUNCION: extraer amplitud/fase en los armonicos n*f0
# ============================================================
def extraer_armonicos(f, P1, fase, f0, Narmonicos):
    armonicos = np.arange(1, Narmonicos + 1) * f0
    amp = np.zeros(Narmonicos)
    ph = np.zeros(Narmonicos)
    for k in range(Narmonicos):
        idx = np.argmin(np.abs(f - armonicos[k]))
        amp[k] = P1[idx]
        ph[k] = fase[idx]
    return armonicos, amp, ph


def extraer_armonicos_osc(f_osc, mag_osc, f0, Narmonicos):
    """
    Busca la magnitud (dB) mas cercana a cada armonico n*f0 dentro del
    espectro exportado por el osciloscopio. Si un armonico cae fuera
    del rango de frecuencias que el instrumento realmente capturo
    (Horizontal Scale limitado), se marca como NaN y se avisa, en vez
    de devolver silenciosamente el valor del extremo del arreglo
    (que no representa ese armonico).
    """
    armonicos = np.arange(1, Narmonicos + 1) * f0
    amp = np.full(Narmonicos, np.nan)
    f_max_capturada = f_osc.max()
    fuera_de_rango = []
    for k in range(Narmonicos):
        if armonicos[k] > f_max_capturada:
            fuera_de_rango.append(int(armonicos[k]))
            continue
        idx = np.argmin(np.abs(f_osc - armonicos[k]))
        amp[k] = mag_osc[idx]
    if fuera_de_rango:
        print(f"    [AVISO] El espectro del osciloscopio solo llega hasta "
              f"{f_max_capturada:.0f} Hz. Los armonicos {fuera_de_rango} Hz "
              f"quedan fuera de rango (posible 'Horizontal Scale' insuficiente "
              f"al capturar el FFT en el instrumento).")
    return amp


# ============================================================
# FUNCION: reconstruccion teorica de un TREN DE PULSOS
# Serie de Fourier: x(t) = Vp*D + sum 2*Vp*sinc(n*D)*cos(2*pi*n*f0*t)
# ============================================================
def reconstruir_pulso_teorico(t, f0, Vp, duty, Narmonicos):
    x_teo = np.full_like(t, duty * Vp, dtype=float)
    for n in range(1, Narmonicos + 1):
        A = (2 * Vp * np.sin(np.pi * n * duty)) / (np.pi * n)
        x_teo += A * np.cos(2 * np.pi * n * f0 * t)
    return x_teo


# ============================================================
# FUNCION: reconstruccion experimental (a partir de armonicos medidos)
# ============================================================
def reconstruir_experimental(t, armonicos, amp, fase):
    x_exp = np.zeros_like(t)
    for k in range(len(armonicos)):
        x_exp += amp[k] * np.cos(2 * np.pi * armonicos[k] * t + fase[k])
    return x_exp


# ============================================================
# PROCESAMIENTO DE CADA SEÑAL DE PULSO
# ============================================================
resumen = []

for s in señales:
    nombre = s["nombre"]
    duty = s["duty"]
    ruta_t = os.path.join(CARPETA_DATOS, s["archivo_tiempo"])
    ruta_f = os.path.join(CARPETA_DATOS, s["archivo_fft"])

    print("\n" + "=" * 60)
    print(f"Procesando: {nombre}  (Duty = {duty*100:.0f}%)")
    print("=" * 60)

    if not os.path.exists(ruta_t) or not os.path.exists(ruta_f):
        print(f"  [AVISO] Archivos no encontrados para {nombre}, se omite.")
        print(f"    Esperado: {ruta_t}")
        print(f"    Esperado: {ruta_f}")
        continue

    # --- Lectura ---
    _, t, x = leer_csv_tektronix(ruta_t)
    _, f_osc, mag_osc = leer_csv_tektronix(ruta_f)

    # --- Calibracion del eje vertical (amplitud) ---
    # El CSV exportado trae la amplitud en cuentas crudas del ADC (el
    # campo Ymult/Yzero necesario para convertir a Volts viene vacio).
    # Se calibra usando el Vp conocido del grupo, asumiendo pulso
    # unipolar entre 0 y Vp (igual que el modelo teorico de mas abajo).
    raw_low, raw_high = x.min(), x.max()
    escala_v = Vp / (raw_high - raw_low)
    x = (x - raw_low) * escala_v
    print(f"  [Calibracion] Amplitud cruda [{raw_low:.1f}, {raw_high:.1f}] "
          f"-> escalada a [0, {Vp}] V")

    # --- Frecuencia de muestreo (calibrada con f0 conocida del grupo) ---
    Fs, f, P1, fase = fft_software(t, x, f0_referencia=f0)
    print(f"  Frecuencia de muestreo (calibrada) = {Fs:.4f} Hz")

    # --- Reescalar el eje de tiempo a segundos reales, usando la Fs calibrada ---
    dt_bruto = np.mean(np.diff(t))
    dt_real = 1 / Fs
    factor_escala = dt_real / dt_bruto
    t = (t - t[0]) * factor_escala   # t ahora en segundos reales, arranca en 0

    # --- Armonicos experimentales ---
    armonicos, amp_sw, fase_sw = extraer_armonicos(f, P1, fase, f0, Narmonicos)
    amp_osc = extraer_armonicos_osc(f_osc, mag_osc, f0, Narmonicos)

    print(f"\n  {'n':>3} {'f (Hz)':>10} {'Amp FFT-SW':>12} {'Amp Osc (dB)':>14}")
    for k in range(Narmonicos):
        txt_osc = f"{amp_osc[k]:>14.2f}" if not np.isnan(amp_osc[k]) else f"{'fuera rango':>14}"
        print(f"  {k+1:>3} {armonicos[k]:>10.1f} {amp_sw[k]:>12.5f} {txt_osc}")

    # --- Reconstrucciones ---
    x_exp = reconstruir_experimental(t, armonicos, amp_sw, fase_sw)
    x_teo = reconstruir_pulso_teorico(t, f0, Vp, duty, Narmonicos)

    # --- Errores RMS ---
    error_teo = np.sqrt(np.mean((x - x_teo) ** 2))
    error_exp = np.sqrt(np.mean((x - x_exp) ** 2))
    print(f"\n  Error RMS teorico      = {error_teo:.6f}")
    print(f"  Error RMS experimental = {error_exp:.6f}")

    resumen.append({
        "señal": nombre, "duty": duty, "Fs": Fs,
        "error_teorico": error_teo, "error_experimental": error_exp,
    })

    # ------------------------------------------------------
    # GRAFICAS
    # ------------------------------------------------------
    # El espectro software (FFT por Python) y el espectro exportado por
    # el osciloscopio tienen escalas muy distintas: uno esta en Volts
    # (lineal) y otro en dB, y ademas cubren rangos de frecuencia muy
    # distintos (el del osciloscopio suele ser mucho mas angosto). Por
    # eso se grafican en dos paneles separados, cada uno con su propio
    # eje X ajustado a donde realmente hay señal, en vez de forzarlos
    # a compartir ejes (lo que aplastaba una de las dos curvas).

    eps = 1e-12
    P1_dB = 20 * np.log10(P1 + eps)  # magnitud software tambien en dB

    # Rango util del eje de frecuencia en cada espectro (hasta donde
    # todavia hay armonicos relevantes, con un 10% de margen)
    xlim_sw = min(f.max(), Narmonicos * f0 * 1.2)
    xlim_osc = f_osc.max() * 1.05

    fig, axs = plt.subplots(4, 1, figsize=(10, 14))

    axs[0].plot(t, x, "k", linewidth=1.2)
    axs[0].set_title(f"{nombre} (Duty={duty*100:.0f}%) - Dominio del tiempo")
    axs[0].set_xlabel("Tiempo (s)")
    axs[0].set_ylabel("Amplitud (V)")
    axs[0].grid(True)

    axs[1].plot(f, P1_dB, "b", linewidth=1.2)
    for n in range(1, Narmonicos + 1):
        axs[1].axvline(n * f0, color="gray", linestyle=":", linewidth=0.6)
    axs[1].set_xlim(0, xlim_sw)
    axs[1].set_title("Espectro calculado por software (FFT Python)")
    axs[1].set_xlabel("Frecuencia (Hz)")
    axs[1].set_ylabel("Magnitud (dB)")
    axs[1].grid(True)

    axs[2].plot(f_osc, mag_osc, "r", linewidth=1)
    axs[2].set_xlim(0, xlim_osc)
    axs[2].set_title("Espectro exportado por el osciloscopio (canal MATH)")
    axs[2].set_xlabel("Frecuencia (Hz)")
    axs[2].set_ylabel("Magnitud (dB)")
    axs[2].grid(True)
    if xlim_osc < f0:
        axs[2].text(0.5, 0.5, f"Fundamental ({f0:.0f} Hz) fuera del rango\n"
                                "capturado por el instrumento",
                     transform=axs[2].transAxes, ha="center", va="center",
                     color="darkred", fontsize=9)

    axs[3].plot(t, x, "k", linewidth=2, label="Original")
    axs[3].plot(t, x_teo, "r", linewidth=1.3, label="Reconstruccion teorica")
    axs[3].plot(t, x_exp, "b--", linewidth=1.3, label="Reconstruccion experimental")
    axs[3].set_title("Comparacion de reconstrucciones")
    axs[3].set_xlabel("Tiempo (s)")
    axs[3].set_ylabel("Amplitud (V)")
    axs[3].legend()
    axs[3].grid(True)

    plt.tight_layout()
    nombre_archivo = nombre.replace(" ", "_")
    ruta_png = os.path.join(CARPETA_SALIDA, f"{nombre_archivo}.png")
    plt.savefig(ruta_png, dpi=120)
    plt.show()
    print(f"  Grafica guardada en: {ruta_png}")

    # --- Tabla de armonicos a CSV ---
    ruta_csv = os.path.join(CARPETA_SALIDA, f"{nombre_archivo}_armonicos.csv")
    with open(ruta_csv, "w", newline="", encoding="utf-8") as f_out:
        escritor = csv.writer(f_out)
        escritor.writerow(["n", "f (Hz)", "Amp_FFT_software", "Amp_Osciloscopio(dB)"])
        for k in range(Narmonicos):
            escritor.writerow([k + 1, armonicos[k], amp_sw[k], amp_osc[k]])
    print(f"  Tabla de armonicos guardada en: {ruta_csv}")

# ============================================================
# RESUMEN FINAL (efecto del ciclo util)
# ============================================================
print("\n" + "=" * 60)
print("RESUMEN - Efecto del ciclo util en las 4 señales de pulso")
print("=" * 60)
print(f"{'Señal':<10}{'Duty (%)':>10}{'Fs (Hz)':>14}{'Err. Teo.':>14}{'Err. Exp.':>14}")
for r in resumen:
    print(f"{r['señal']:<10}{r['duty']*100:>10.0f}{r['Fs']:>14.2f}"
          f"{r['error_teorico']:>14.6f}{r['error_experimental']:>14.6f}")
