import matplotlib.pyplot as plt
import csv
import sys
import numpy as np
import math

# ================================
# 1. PARÁMETROS EDITABLES POR EL USUARIO
# ================================
f0 = 3500                # Frecuencia fundamental [Hz]
Vp = 1.5                 # Voltaje pico [V]
tipo_senal = 'pulso'     # Opciones: 'sinusoidal', 'cuadrada', 'triangular', 'pulso'
ciclo_trabajo = 0.5      # Solo para 'pulso' (0 < duty < 1)
num_armonicos = 5        # Número de armónicos a considerar (incluye fundamental)

# Nombres de los archivos
archivo_tiempo = 'Pulso 1tiemdta.csv'
archivo_fft = 'Pulso 1DTA.csv'  # Si no existe, se omite la comparación

# Opciones adicionales
usar_ventana = True      # True para aplicar ventana de Hann antes de la FFT
escalar_espectro = True  # True para escalar la fundamental a la teórica

# ================================
# 2. LECTURA DE ARCHIVOS (VERSIÓN ROBUSTA)
# ================================
print("Leyendo archivos...")
datos_tiempo_x = []
datos_tiempo_y = []

try:
    with open(archivo_tiempo, 'r', encoding='latin-1') as archivo:
        # --- Detecta si el separador es coma o punto y coma ---
        primera_linea = archivo.readline()
        archivo.seek(0) # Vuelve al principio del archivo
        
        if ';' in primera_linea:
            delimitador = ';'
        else:
            delimitador = ','
            
        lector = csv.reader(archivo, delimiter=delimitador)
        
        for fila in lector:
            if len(fila) < 2:
                continue # Salta filas sin datos o con formato extraño
            try:
                # .strip() elimina espacios en blanco antes y después del número
                tiempo = float(fila[0].replace(',', '.').strip())
                voltaje = float(fila[1].replace(',', '.').strip())
                datos_tiempo_x.append(tiempo)
                datos_tiempo_y.append(voltaje)
            except ValueError:
                continue # Salta la fila si no es un número (así omite la cabecera de títulos)
                
    # *** COMPROBACIÓN DE SEGURIDAD ***
    if len(datos_tiempo_x) == 0:
        print("\n❌ ERROR CRÍTICO: No se encontraron datos numéricos en el archivo CSV.")
        print(f"Revisa el contenido de '{archivo_tiempo}'. Asegúrate de que:")
        print("1. El archivo tenga al menos una columna de Tiempo y una de Voltaje (separadas por coma ',' o punto y coma ';').")
        print("2. La primera fila de datos NO sea un encabezado, o si lo es, que haya más filas de números abajo.")
        sys.exit(1)

    print(f"✅ Archivo de tiempo leído correctamente. ({len(datos_tiempo_x)} muestras cargadas).")
    
except FileNotFoundError:
    print(f"❌ Error: No se encontró el archivo '{archivo_tiempo}'.")
    sys.exit(1)
except Exception as e:
    print(f"❌ Error fatal al leer el archivo: {e}")
    sys.exit(1)

# ================================
# 3. CÁLCULO DE LA FFT
# ================================
print("Procesando datos y aplicando FFT...")
x = np.array(datos_tiempo_x)
y = np.array(datos_tiempo_y)

N = len(x)
Fs = 1.0 / (x[1] - x[0]) if N > 1 else 1.0

if usar_ventana:
    ventana = np.hanning(N)
    y_ventaneado = y * ventana
else:
    ventana = np.ones(N)
    y_ventaneado = y

Y = np.fft.fft(y_ventaneado)
freqs = np.fft.fftfreq(N, 1.0 / Fs)

idx_pos = freqs >= 0
freqs_pos = freqs[idx_pos]
magnitud_fft = np.abs(Y[idx_pos])

# Factor de escala
if usar_ventana:
    factor_escala = 2.0 / np.sum(ventana)
else:
    factor_escala = 2.0 / N

magnitud_fft = magnitud_fft * factor_escala
magnitud_fft[0] = magnitud_fft[0] / 2.0 * (2.0 if usar_ventana else 1.0) 

if escalar_espectro:
    idx_f0 = np.argmin(np.abs(freqs_pos - f0))
    amp_teorica_f0 = (2 * Vp) / (math.pi * 1) * abs(math.sin(math.pi * 1 * ciclo_trabajo))
    factor_ajuste = amp_teorica_f0 / magnitud_fft[idx_f0]
    magnitud_fft = magnitud_fft * factor_ajuste

# ================================
# 4. CÁLCULO DE LA SEÑAL TEÓRICA
# ================================
frecuencias_teoricas = [f0 * i for i in range(1, num_armonicos + 1)]
amplitudes_teoricas = []

for k in range(1, num_armonicos + 1):
    amp = (2 * Vp) / (k * math.pi) * abs(math.sin(k * math.pi * ciclo_trabajo))
    amplitudes_teoricas.append(amp)

print("Procesamiento completado. Generando gráficas...")

# ================================
# 5. COMPARACIÓN CON ARCHIVO FFT
# ================================
x_fft_ext = []
y_fft_ext = []
try:
    with open(archivo_fft, 'r', encoding='latin-1') as archivo:
        lector = csv.reader(archivo, delimiter=delimitador)
        for fila in lector:
            if len(fila) >= 2:
                x_fft_ext.append(float(fila[0].replace(',', '.')))
                y_fft_ext.append(float(fila[1].replace(',', '.')))
    tiene_fft_ext = True
    print("Archivo de FFT externo encontrado para comparación.")
except:
    tiene_fft_ext = False
    print("Archivo de FFT externo no encontrado (omitiendo comparación).")

# ================================
# 6. GRÁFICAS
# ================================
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
plt.subplots_adjust(hspace=0.4)

ax1.plot(x * 1000, y, 'b-', linewidth=1.5, label='Señal experimental')
ax1.set_title(f'Señal en el Tiempo (f0 = {f0} Hz, {tipo_senal.capitalize()})')
ax1.set_xlabel('Tiempo (ms)')
ax1.set_ylabel('Voltaje (V)')
ax1.grid(True, linestyle='--', alpha=0.7)
ax1.legend()

freq_max_plot = f0 * (num_armonicos + 1)
idx_plot = freqs_pos <= freq_max_plot

ax2.plot(freqs_pos[idx_plot], magnitud_fft[idx_plot], 'b-', linewidth=1.5, label='FFT Experimental')
ax2.stem(frecuencias_teoricas, amplitudes_teoricas, linefmt='r-', markerfmt='ro', basefmt='k-', label='Teórico')

if tiene_fft_ext:
    x_fft_ext_arr = np.array(x_fft_ext)
    y_fft_ext_arr = np.array(y_fft_ext)
    idx_ext = x_fft_ext_arr <= freq_max_plot
    ax2.plot(x_fft_ext_arr[idx_ext], y_fft_ext_arr[idx_ext], 'g--', linewidth=1.5, label='FFT Externa')

ax2.set_title('Espectro de Frecuencias (FFT vs Teórico)')
ax2.set_xlabel('Frecuencia (Hz)')
ax2.set_ylabel('Amplitud (V)')
ax2.grid(True, linestyle='--', alpha=0.7)
ax2.legend()

plt.show()