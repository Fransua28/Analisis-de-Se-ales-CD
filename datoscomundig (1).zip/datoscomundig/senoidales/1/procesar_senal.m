%% ========================================================================
%  PROCESAMIENTO DE SEÑALES DE OSCILOSCOPIO (TDS 2012B)
%  Laboratorio de Comunicaciones Digitales
%  ========================================================================
%  Este script lee archivos CSV de tiempo y FFT, calcula la FFT por software,
%  extrae armónicos, reconstruye la señal y compara con la original.
%  ========================================================================

%% 1. PARÁMETROS EDITABLES POR EL USUARIO
% -------------------------------------------------------------------------
f0 = 3500;                 % Frecuencia fundamental [Hz]
Vp = 1.5;                    % Voltaje pico [V]
tipo_senal = 'sinusoidal';   % Opciones: 'sinusoidal', 'cuadrada', 'triangular', 'pulso'
ciclo_trabajo = 0.5;       % Solo para 'pulso' (0 < duty < 1)
num_armonicos = 15;         % Número de armónicos a considerar (incluye fundamental)

% Nombres de los archivos (ajusta según tus archivos)
archivo_tiempo = 'Senoidal1tiempodata.csv';
archivo_fft     = 'Senoidal1DATA.csv';   % Si no existe, se omite la comparación

% -------------------------------------------------------------------------
% LLAMADA A LA FUNCIÓN PRINCIPAL (con nombre distinto al del archivo)
% -------------------------------------------------------------------------
procesar_datos(archivo_tiempo, archivo_fft, f0, Vp, tipo_senal, ciclo_trabajo, num_armonicos);

%% ========================================================================
%  FUNCIONES (TODAS A PARTIR DE AQUÍ)
%  ========================================================================

% -------------------------------------------------------------------------
% 2. FUNCIÓN PRINCIPAL DE PROCESAMIENTO
% -------------------------------------------------------------------------
function procesar_datos(t_file, fft_file, f0, Vp, tipo, duty, Nharm)
    % t_file   : nombre del archivo CSV con datos en tiempo
    % fft_file : nombre del archivo CSV con espectro del osciloscopio
    % f0       : frecuencia fundamental (Hz)
    % Vp       : amplitud pico (V)
    % tipo     : tipo de señal ('sinusoidal', 'cuadrada', 'triangular', 'pulso')
    % duty     : ciclo de trabajo (0-1) para 'pulso'
    % Nharm    : número de armónicos a extraer y usar en reconstrucción

    fprintf('Leyendo archivos...\n');
    [t, senal] = leer_csv(t_file);
    [f_osc, mag_osc] = leer_csv(fft_file);

    if isempty(t) || isempty(senal)
        error('No se pudieron leer los datos del archivo de tiempo.');
    end
    if isempty(f_osc) || isempty(mag_osc)
        warning('No se pudo leer el archivo FFT. Se omitirá la comparación con el osciloscopio.');
        mag_osc = [];
        f_osc = [];
    end

    % Cálculo de la tasa de muestreo
    dt = mean(diff(t));
    fs = 1 / dt;
    fprintf('Frecuencia de muestreo estimada: %.2f Hz\n', fs);

    % FFT por software
    N = length(senal);
    Y = fft(senal);
    P2 = abs(Y / N);
    P1 = P2(1 : floor(N/2) + 1);
    P1(2 : end-1) = 2 * P1(2 : end-1);
    f = fs * (0 : floor(N/2)) / N;
    fase = angle(Y(1 : floor(N/2) + 1));
    dc = mean(senal);   % componente DC

    % Figura 1: señal en el tiempo
    figure('Name', 'Señal en el tiempo', 'NumberTitle', 'off');
    plot(t, senal, 'b-', 'LineWidth', 1.5);
    xlabel('Tiempo (s)');
    ylabel('Amplitud (V)');
    title('Señal capturada (dominio del tiempo)');
    grid on;

    % Figura 2: espectros
    figure('Name', 'Espectro', 'NumberTitle', 'off');
    plot(f, P1, 'b-', 'LineWidth', 1.5);
    hold on;
    if ~isempty(mag_osc)
        plot(f_osc, mag_osc, 'r--', 'LineWidth', 1.5);
        legend('FFT calculada', 'FFT osciloscopio', 'Location', 'best');
    else
        legend('FFT calculada', 'Location', 'best');
    end
    xlabel('Frecuencia (Hz)');
    ylabel('Magnitud (V)');
    title('Comparación de espectros');
    grid on;
    xlim([0, 10*f0]);
    hold off;

    % Extracción de armónicos
    [mag_calc, fase_calc] = extraer_armonicos(f, P1, fase, f0, Nharm);
    if ~isempty(mag_osc)
        [mag_osc_arm, ~] = extraer_armonicos(f_osc, mag_osc, zeros(size(mag_osc)), f0, Nharm);
    else
        mag_osc_arm = NaN(1, Nharm);
    end
    [mag_teo, fase_teo] = armonicos_teoricos(tipo, f0, Vp, duty, Nharm);

    % Escalar espectros medidos para que la fundamental coincida con la teórica
    if mag_teo(1) ~= 0 && mag_calc(1) ~= 0
        factor = mag_teo(1) / mag_calc(1);
        mag_calc = mag_calc * factor;
        mag_osc_arm = mag_osc_arm * factor;
    end

    % Mostrar tabla de magnitudes
    fprintf('\n--- MAGNITUDES DE LOS PRIMEROS %d ARMÓNICOS ---\n', Nharm);
    fprintf('Armónico\tTeórica (V)\tCalculada (V)\tOsciloscopio (V)\n');
    for k = 1:Nharm
        fprintf('%d\t\t%.4f\t\t%.4f\t\t%.4f\n', k, mag_teo(k), mag_calc(k), mag_osc_arm(k));
    end

    % Reconstrucción de la señal
    t_recon = t;
    senal_teo = reconstruir_serie(t_recon, f0, mag_teo, fase_teo, Nharm, dc);
    fase_exp = zeros(1, Nharm);
    senal_exp = reconstruir_serie(t_recon, f0, mag_calc, fase_exp, Nharm, dc);

    % Figura 3: reconstrucciones
    figure('Name', 'Reconstrucciones', 'NumberTitle', 'off');
    plot(t, senal, 'k-', 'LineWidth', 2); hold on;
    plot(t_recon, senal_teo, 'b--', 'LineWidth', 1.5);
    plot(t_recon, senal_exp, 'r-.', 'LineWidth', 1.5);
    xlabel('Tiempo (s)');
    ylabel('Amplitud (V)');
    title('Comparación: señal original vs reconstrucciones');
    legend('Original', 'Teórica (Fourier)', 'Experimental (CSV)', 'Location', 'best');
    grid on;
    hold off;

    fprintf('\nProcesamiento completado.\n');
end

% -------------------------------------------------------------------------
% 3. FUNCIONES AUXILIARES
% -------------------------------------------------------------------------

% 3.1 Leer archivo CSV buscando números en cualquier columna
function [x, y] = leer_csv(filename)
    fid = fopen(filename, 'r');
    if fid == -1
        error('No se pudo abrir el archivo: %s', filename);
    end

    data = [];
    tline = fgetl(fid);
    while ischar(tline)
        parts = strsplit(tline, ',');
        nums = [];
        for i = 1:length(parts)
            val = convertir_numero(strtrim(parts{i}));
            if ~isnan(val)
                nums = [nums, val];
            end
        end
        if length(nums) >= 2
            data = [data; nums(1), nums(2)];
        end
        tline = fgetl(fid);
    end
    fclose(fid);

    if isempty(data)
        error('No se encontraron datos numéricos en el archivo.');
    end
    x = data(:,1);
    y = data(:,2);
end

% 3.2 Convertir string a número ('.' -> 0)
function val = convertir_numero(str)
    str = strtrim(str);
    if strcmp(str, '.')
        val = 0;
    else
        val = str2double(str);
    end
end

% 3.3 Extraer armónicos de un espectro
function [mags, fases] = extraer_armonicos(freq, mag, phase, f0, N)
    mags = zeros(1, N);
    fases = zeros(1, N);
    for k = 1:N
        f_objetivo = k * f0;
        [~, idx] = min(abs(freq - f_objetivo));
        mags(k) = mag(idx);
        fases(k) = phase(idx);
    end
end

% 3.4 Coeficientes teóricos de Fourier según tipo de señal
function [mags, fases] = armonicos_teoricos(tipo, f0, Vp, duty, N)
    mags = zeros(1, N);
    fases = zeros(1, N);   % fase cero para señales simétricas

    switch lower(tipo)
        case 'sinusoidal'
            mags(1) = Vp;
        case 'cuadrada'
            for k = 1:N
                if mod(k, 2) == 1
                    mags(k) = 4 * Vp / (pi * k);
                end
            end
        case 'triangular'
            for k = 1:N
                if mod(k, 2) == 1
                    mags(k) = 8 * Vp / (pi^2 * k^2);
                end
            end
        case 'pulso'
            if duty <= 0 || duty >= 1
                error('El ciclo de trabajo debe estar entre 0 y 1.');
            end
            for k = 1:N
                mags(k) = Vp * duty * sinc(k * duty);
            end
        otherwise
            error('Tipo de señal no reconocido. Use: sinusoidal, cuadrada, triangular, pulso');
    end
end

% 3.5 Reconstruir señal por superposición de armónicos
function senal_recon = reconstruir_serie(t, f0, mags, fases, N, dc)
    senal_recon = dc * ones(size(t));
    for k = 1:N
        if mags(k) ~= 0
            senal_recon = senal_recon + mags(k) * cos(2*pi*k*f0*t + fases(k));
        end
    end
end