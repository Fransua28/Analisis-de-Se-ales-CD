%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ANALISIS DE SEÑALES - SERIES DE FOURIER
%
% Lee automáticamente:
%   1. Archivo CSV del dominio del tiempo
%   2. Archivo CSV del espectro FFT exportado por el osciloscopio
%
% Calcula:
%   - Frecuencia de muestreo
%   - FFT por software
%   - Comparación FFT MATLAB vs Osciloscopio
%   - Primeros armónicos
%   - Reconstrucción teórica
%   - Reconstrucción experimental
%
% Compatible con MATLAB R2019 o superior
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
close all
clc

%% ============================
% ARCHIVOS
%% ============================

archivoTiempo = 'Senoidal1tiempodata.csv';
archivoFFT    = 'Senoidal1DATA.csv';

%% ============================
% PARAMETROS
%% ============================

tipo = 'senoidal';          % senoidal, cuadrada, triangular, pulso

f0 = 3500;                  % Frecuencia fundamental (Hz)

Vp = 1.5;                     % Voltaje pico (V)

Duty = 0.50;                % Ciclo útil (solo para pulso)

Narmonicos = 15;

%% ===========================================================
% LECTURA AUTOMATICA DEL ARCHIVO DE TIEMPO
%% ===========================================================

opts = detectImportOptions(archivoTiempo);

opts.VariableNamesLine = 0;

try
    datos = readmatrix(archivoTiempo,opts);
catch
    datos = readmatrix(archivoTiempo);
end

datos = datos(:,1:2);
datos = datos(~any(isnan(datos),2),:);

t = datos(:,1);
x = datos(:,2);

%% ===========================================================
% LECTURA FFT OSCILOSCOPIO
%% ===========================================================

opts2 = detectImportOptions(archivoFFT);

opts2.VariableNamesLine = 0;

try
    datosFFT = readmatrix(archivoFFT,opts2);
catch
    datosFFT = readmatrix(archivoFFT);
end

datosFFT = datosFFT(:,1:2);
datosFFT = datosFFT(~any(isnan(datosFFT),2),:);

fOSC = datosFFT(:,1);
magOSC = datosFFT(:,2);

%% ===========================================================
% FRECUENCIA DE MUESTREO
%% ===========================================================

dt = mean(diff(t));

Fs = 1/dt;

fprintf('\n');
fprintf('Frecuencia de muestreo = %.4f Hz\n',Fs);

%% ===========================================================
% GRAFICA DOMINIO DEL TIEMPO
%% ===========================================================

figure

plot(t,x,'b','LineWidth',1.5)

grid on

xlabel('Tiempo (s)')

ylabel('Voltaje (V)')

title('Dominio del tiempo')

%% ===========================================================
% FFT MATLAB
%% ===========================================================

N = length(x);

Y = fft(x);

P2 = abs(Y)/N;

n2 = floor(N/2);

P1 = P2(1:n2+1);

if length(P1)>2
    P1(2:end-1)=2*P1(2:end-1);
end

fase = angle(Y(1:n2+1));

f = Fs*(0:n2)/N;

%% ===========================================================
% FFT MATLAB
%% ===========================================================

figure

plot(f,P1,'b','LineWidth',1.5)

grid on

xlabel('Frecuencia (Hz)')

ylabel('Magnitud')

title('FFT calculada con MATLAB')

xlim([0 10*f0])

%% ===========================================================
% COMPARACION FFT
%% ===========================================================

figure

plot(f,P1,'b','LineWidth',1.5)

hold on

plot(fOSC,magOSC,'r')

grid on

legend('MATLAB','Osciloscopio')

xlabel('Frecuencia (Hz)')

ylabel('Magnitud')

title('Comparación de espectros')

xlim([0 10*f0])

%% ===========================================================
% PRIMEROS ARMONICOS
%% ===========================================================

fprintf('\n');
fprintf('==============================\n');
fprintf('Primeros armónicos\n');
fprintf('==============================\n');

armonicos = (1:Narmonicos)'*f0;

AmpMATLAB = zeros(Narmonicos,1);
AmpOSC = zeros(Narmonicos,1);
FaseMATLAB = zeros(Narmonicos,1);

for k=1:Narmonicos

    [~,idx]=min(abs(f-armonicos(k)));

    AmpMATLAB(k)=P1(idx);

    FaseMATLAB(k)=fase(idx);

    [~,idx2]=min(abs(fOSC-armonicos(k)));

    AmpOSC(k)=magOSC(idx2);

end

Tabla = table(armonicos,AmpMATLAB,AmpOSC)

%% ===========================================================
% RECONSTRUCCION EXPERIMENTAL
%% ===========================================================

xEXP = zeros(size(t));

for k=1:Narmonicos

    xEXP = xEXP + ...
        AmpMATLAB(k)*cos(2*pi*armonicos(k)*t + FaseMATLAB(k));

end

%% ===========================================================
% RECONSTRUCCION TEORICA
%% ===========================================================

xTEO = zeros(size(t));

switch lower(tipo)

    case 'senoidal'

        xTEO = Vp*cos(2*pi*f0*t);

    case 'cuadrada'

        for n=1:2:(2*Narmonicos-1)

            A = 4*Vp/(pi*n);

            xTEO = xTEO + ...
                A*sin(2*pi*n*f0*t);

        end

    case 'triangular'

        signo = 1;

        for n=1:2:(2*Narmonicos-1)

            A = signo*(8*Vp)/(pi^2*n^2);

            xTEO = xTEO + ...
                A*sin(2*pi*n*f0*t);

            signo = -signo;

        end

    case 'pulso'

        xTEO = Duty*Vp;

        for n=1:Narmonicos

            A = (2*Vp*sin(pi*n*Duty))/(pi*n);

            xTEO = xTEO + ...
                A*cos(2*pi*n*f0*t);

        end

end

%% ===========================================================
% COMPARACION FINAL
%% ===========================================================

figure

plot(t,x,'k','LineWidth',2)

hold on

plot(t,xTEO,'r','LineWidth',1.5)

plot(t,xEXP,'b--','LineWidth',1.5)

grid on

xlabel('Tiempo (s)')

ylabel('Voltaje (V)')

legend('Original','Reconstrucción teórica','Reconstrucción experimental')

title('Comparación de señales')

%% ===========================================================
% ERROR RMS
%% ===========================================================

errorTeorico = sqrt(mean((x-xTEO).^2));

errorExperimental = sqrt(mean((x-xEXP).^2));

fprintf('\n');
fprintf('Error RMS Teórico      = %.6f V\n',errorTeorico);
fprintf('Error RMS Experimental = %.6f V\n',errorExperimental);